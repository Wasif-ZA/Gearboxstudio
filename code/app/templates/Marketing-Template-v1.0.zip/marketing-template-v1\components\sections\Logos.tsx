import { Component } from "lucide-react";

export function Logos() {
    return (
        <section className="py-12 border-y border-border/50 bg-page">
            <div className="container px-4 md:px-6">
                <p className="mb-8 text-center text-sm font-medium text-secondary/60 uppercase tracking-widest">
                    Trusted by Innovative Teams
                </p>
                <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-50 grayscale transition-all hover:opacity-100 hover:grayscale-0">
                    {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="flex items-center gap-2">
                            <Component className="h-8 w-8 text-secondary" />
                            <span className="text-xl font-bold text-secondary">Company {i}</span>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
