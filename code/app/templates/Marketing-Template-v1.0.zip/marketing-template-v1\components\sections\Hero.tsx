import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

export function Hero() {
    return (
        <section className="relative flex min-h-[80vh] flex-col items-center justify-center overflow-hidden px-4 md:px-6 py-24 text-center">
            {/* Glow Effect */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-accent/20 rounded-full blur-[120px] -z-10" />

            {/* Badge */}
            <div className="mb-6 inline-flex items-center rounded-full border border-accent/20 bg-accent/10 sm:px-4 px-3 sm:py-1.5 py-1 text-sm font-medium text-accent">
                <Sparkles className="mr-2 h-4 w-4" />
                <span className="text-xs sm:text-sm">New v1.0 Released</span>
            </div>

            {/* Heading */}
            <h1 className="mb-6 max-w-4xl text-5xl font-bold tracking-tight text-white md:text-7xl">
                Build your next SaaS <br className="hidden md:block" />
                with <span className="text-accent">Precision</span>
            </h1>

            {/* Subheading */}
            <p className="mb-8 max-w-2xl text-lg text-secondary md:text-xl">
                The premium, neutral template for serious developers.
                Ship your marketing site in hours, not days.
            </p>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="h-12 px-8 text-base">
                    Get Started Now
                    <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" size="lg" className="h-12 px-8 text-base">
                    View Documentation
                </Button>
            </div>

            {/* Image Placeholder / Visual */}
            <div className="mt-16 w-full max-w-5xl rounded-xl border border-border bg-surface/50 p-2 backdrop-blur-sm">
                <div className="aspect-video w-full rounded-lg bg-page/50 object-cover" />
                {/* In real product, this would be an image or dashboard screenshot */}
                <div className="absolute inset-0 flex items-center justify-center text-secondary/50">
                    <span className="text-sm">App Screenshot Placeholder</span>
                </div>
            </div>
        </section>
    );
}
