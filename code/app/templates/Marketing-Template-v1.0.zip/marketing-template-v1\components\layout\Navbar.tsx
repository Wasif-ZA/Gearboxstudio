"use client";

import * as React from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigation = [
    { name: "Features", href: "#features" },
    { name: "Pricing", href: "/pricing" },
    { name: "About", href: "#about" },
];

export function Navbar() {
    const [isOpen, setIsOpen] = React.useState(false);

    return (
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-page/80 backdrop-blur-md">
            <div className="container flex h-16 items-center justify-between px-4 md:px-6">
                <div className="flex gap-6 md:gap-10">
                    <Link href="/" className="flex items-center space-x-2">
                        <span className="inline-block h-6 w-6 rounded-lg bg-accent" />
                        <span className="hidden font-bold sm:inline-block text-primary">
                            Product
                        </span>
                    </Link>
                    <nav className="hidden gap-6 md:flex">
                        {navigation.map((item) => (
                            <Link
                                key={item.href}
                                href={item.href}
                                className="flex items-center text-sm font-medium text-secondary transition-colors hover:text-primary"
                            >
                                {item.name}
                            </Link>
                        ))}
                    </nav>
                </div>
                <div className="flex items-center gap-4">
                    <div className="hidden md:flex md:gap-4">
                        <Button variant="ghost" size="sm">
                            Sign In
                        </Button>
                        <Button size="sm">Get Started</Button>
                    </div>
                    <Button
                        variant="ghost"
                        size="icon"
                        className="md:hidden"
                        onClick={() => setIsOpen(!isOpen)}
                    >
                        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                        <span className="sr-only">Toggle Menu</span>
                    </Button>
                </div>
            </div>
            {/* Mobile Menu */}
            {isOpen && (
                <div className="fixed inset-0 top-16 z-50 grid h-[calc(100vh-4rem)] grid-flow-row auto-rows-max overflow-auto p-6 pb-32 sm:hidden bg-page animate-in slide-in-from-bottom-10 fade-in-20">
                    <div className="relative z-20 grid gap-6 rounded-md bg-surface p-4 shadow-md">
                        <nav className="grid grid-flow-row auto-rows-max text-sm">
                            {navigation.map((item) => (
                                <Link
                                    key={item.href}
                                    href={item.href}
                                    className="flex w-full items-center rounded-md p-2 text-sm font-medium text-secondary hover:text-primary hover:bg-page/50"
                                    onClick={() => setIsOpen(false)}
                                >
                                    {item.name}
                                </Link>
                            ))}
                            <Link
                                href="/contact"
                                className="flex w-full items-center rounded-md p-2 text-sm font-medium text-secondary hover:text-primary hover:bg-page/50"
                                onClick={() => setIsOpen(false)}
                            >
                                Contact
                            </Link>
                        </nav>
                        <div className="mt-4 flex flex-col gap-2">
                            <Button className="w-full">Get Started</Button>
                            <Button variant="outline" className="w-full">Sign In</Button>
                        </div>
                    </div>
                </div>
            )}
        </header>
    );
}
