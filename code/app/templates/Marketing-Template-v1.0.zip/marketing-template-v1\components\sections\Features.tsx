import { BarChart3, CloudLightning, Fingerprint, RefreshCcw, Shield, Zap } from "lucide-react";

const features = [
    {
        name: "Lightning Fast Information",
        description:
            "Optimize your workflow with zero-latency data processing and real-time updates.",
        icon: Zap,
    },
    {
        name: "Secure by Design",
        description:
            "Enterprise-grade encryption and security protocols protecting your data 24/7.",
        icon: Shield,
    },
    {
        name: "Advanced Analytics",
        description:
            "Deep dive into your metrics with our powerful, intuitive dashboard tools.",
        icon: BarChart3,
    },
    {
        name: "Cloud Synchronization",
        description:
            "Seamlessly sync across all devices with our robust cloud infrastructure.",
        icon: CloudLightning,
    },
    {
        name: "Biometric Authentication",
        description:
            "Next-gen security using fingerprint and face recognition technology.",
        icon: Fingerprint,
    },
    {
        name: "Automated Workflows",
        description:
            "Set it and forget it. Automate your repetitive tasks with smart triggers.",
        icon: RefreshCcw,
    },
];

export function Features() {
    return (
        <section id="features" className="py-24 bg-surface/50">
            <div className="container px-4 md:px-6">
                <div className="mb-12 text-center">
                    <h2 className="text-3xl font-bold tracking-tighter text-primary sm:text-4xl md:text-5xl">
                        Everything you need for <span className="text-accent">Success</span>
                    </h2>
                    <p className="mx-auto mt-4 max-w-[700px] text-secondary md:text-xl">
                        Powerful features designed to help you scale your business without the headache.
                    </p>
                </div>
                <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
                    {features.map((feature) => (
                        <div
                            key={feature.name}
                            className="group relative rounded-2xl border border-border bg-page p-6 transition-colors hover:border-accent/40"
                        >
                            <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10 text-accent group-hover:bg-accent group-hover:text-white transition-colors duration-300">
                                <feature.icon className="h-6 w-6" />
                            </div>
                            <h3 className="mb-2 text-lg font-semibold text-primary">
                                {feature.name}
                            </h3>
                            <p className="text-sm text-secondary leading-relaxed">
                                {feature.description}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
