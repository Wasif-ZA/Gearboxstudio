import type { Config } from "tailwindcss";

const config: Config = {
    content: [
        "./components/**/*.{js,ts,jsx,tsx,mdx}",
        "./app/**/*.{js,ts,jsx,tsx,mdx}",
    ],
    theme: {
        extend: {
            colors: {
                page: "#0B0F14",        // Deep Navy/Black
                surface: "#111621",     // Card background
                border: "#1F2937",      // Subtle border
                primary: "#F3F4F6",     // Heading text
                secondary: "#9CA3AF",   // Body text
                accent: {
                    DEFAULT: "#3B82F6",   // Electric Blue
                    hover: "#2563EB",
                }
            }
        },
    },
    plugins: [],
};
export default config;
